

$system int foo(void);
