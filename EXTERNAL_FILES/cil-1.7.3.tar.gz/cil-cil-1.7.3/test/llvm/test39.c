#include <stdio.h>

static int x = 99;

int main(int argc, char **argv)
{
  printf("hello world %d\n", x);
  return 0;
}
