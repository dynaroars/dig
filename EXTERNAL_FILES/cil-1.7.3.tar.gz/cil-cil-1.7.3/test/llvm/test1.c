#include <stdio.h>

int x;

int main(int argc, char **argv)
{
  x = 2;
  printf("hello world\n");
  return 0;
}
