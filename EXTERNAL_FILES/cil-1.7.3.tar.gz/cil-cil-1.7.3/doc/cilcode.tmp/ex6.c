  int a1[] = {1,2,3};
  int a2[sizeof(int) >= 4 ? 8 : 16];
