  int main () {
    int ***three;
    int **two;
    ***three = **two; 
  } 
