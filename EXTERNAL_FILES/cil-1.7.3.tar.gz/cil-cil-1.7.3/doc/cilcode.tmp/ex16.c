int main(void) {
# 1
   int x, f(int);
   return (x ++ + f(x));
}
