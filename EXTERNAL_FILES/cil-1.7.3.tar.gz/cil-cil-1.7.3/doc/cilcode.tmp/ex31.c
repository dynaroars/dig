int main(void) {
# 1
 return (((1 - sizeof(int)) >> 16) >> 16);
}
