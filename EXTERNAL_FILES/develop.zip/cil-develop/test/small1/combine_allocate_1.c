__inline static void *allocate(unsigned int __8318_34___n ) ;
