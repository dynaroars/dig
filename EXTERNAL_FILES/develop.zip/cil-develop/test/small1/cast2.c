void free(void*);

void foo()
{
  (void)free(0);
}
