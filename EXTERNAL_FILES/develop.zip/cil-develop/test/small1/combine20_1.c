

static int tmp  ;

int usetmp() {
  return tmp;
}
