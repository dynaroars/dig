
int main(){
  asm ("xor %%eax, %%eax"
       : /* No outputs. */
       : /* No inputs */
       : );
  return(0);
}
