struct pci_device_info {
	unsigned short device;
	unsigned short seen;
	const char *name;
};

struct pci_device_info __devices_0000 []
__attribute__ ((__section__ (".data.init")))  = { };

