
int main() {
    __annotation(L"TMC:", L"f25b6b4c" L"-" L"98d9" L"-" L"41bf" L"-" L"bf48" L"-" L"36255d508a22", L"AmccS5933DK1TraceGuid" ,
                 L"RDK_TRACE_INIT" , L"RDK_TRACE_SHUTDOWN" , L"RDK_TRACE_IO");
    __annotation(L"TMC:", L"5a08c3db" L"-" L"5c89" L"-" L"4089" L"-" L"bfdc" L"-" L"6b7b679faac3", L"AmccS5933DK1TraceGuid2" ,
                 L"RDK2_TRACE_THIS" , L"RDK2_TRACE_THAT"); 
}

