#include "testharness.h"

// CIL seems to drop this on the floor!!!
extern int main(int argc) {
  return 0;
}
