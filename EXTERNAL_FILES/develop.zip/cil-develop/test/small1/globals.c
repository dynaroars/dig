
static int *glob2;

int *glob1 = (int*) & glob2;

static int *glob2 = (int*) & glob1;

int arr2[10];
int arr2[10];
int arr2[10];

