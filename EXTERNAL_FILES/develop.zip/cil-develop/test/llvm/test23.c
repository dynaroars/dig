#include <stdio.h>

int a[4] = { 0, 4, 7, -1 };

int main(int argc, char **argv)
{
  printf("hello world %d %d %d\n", a[1], a[2], a[3]);
  return 0;
}
