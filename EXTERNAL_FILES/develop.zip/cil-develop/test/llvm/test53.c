#include <stdio.h>

double x;

int main(int argc, char **argv)
{
  x = -1.0E+15;
  printf("hello world %g\n", x);
  return 0;
}
